T1 0.800000mm  18x [12.700000 | 27.940000]
T2 1.000000mm  6x [20.320000 | 9.525000]
T3 1.400000mm  1x [26.035000 | 22.225000]

; 3 Outils
; 25 per�ages
; Le plus petit foret: 0.800000mm

; Les diam�tres indiqu�s sont des mesures finales.
; Par exp�rience, les diam�tres doivent �tre diff�rents.

